// @ts-check
// @ts-ignore
// iPanel配置项
window.iPanelWebConsoleConfig ||= {
    /**
     * 路由历史类型
     * - 如果不能设置单页面应用模式，则需将此项改为`hash`
     * @type {"web"|"hash"|"memory"}
     */
    routerHistoryType: "web",
};
